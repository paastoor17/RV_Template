﻿using UnityEngine;
namespace Autohand{
    public class PlayerPlatform : MonoBehaviour{
        
    }
}